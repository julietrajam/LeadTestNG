package testcase;




import java.io.IOException;

//import java.time.Duration;

import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

//import io.github.bonigarcia.wdm.WebDriverManager;

public class CreateLeadReadExcelDataProvider extends BaseClass {

	@Test(dataProvider = "fetchData")
	public void runCreateLead(String cName,String fName,String lName,String pNo) {
		
		driver.findElement(By.linkText("Create Lead")).click();
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cName);
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fName);
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lName);
		driver.findElement(By.id("createLeadForm_primaryPhoneNumber")).sendKeys(pNo);
		driver.findElement(By.name("submitButton")).click();
		
}
	
	@DataProvider(name = "fetchData")
	public String[][] sendData() throws IOException{
		
		return ReadExcelDataProvider.readData("CreateLead");
		
		
	}
}








