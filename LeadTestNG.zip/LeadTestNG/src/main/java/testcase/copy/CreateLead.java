package testcase.copy;




//import java.time.Duration;

import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

//import io.github.bonigarcia.wdm.WebDriverManager;

public class CreateLead extends BaseClass {

	@Test(dataProvider = "fetchData")
	public void runCreateLead(String cName,String fName,String lName,String pNo) {
		
		driver.findElement(By.linkText("Create Lead")).click();
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cName);
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fName);
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lName);
		driver.findElement(By.id("createLeadForm_primaryPhoneNumber")).sendKeys(pNo);
		driver.findElement(By.name("submitButton")).click();
		
}
	
	@DataProvider(name = "fetchData")
	public String[][] sendData(){
		
		String[][] data=new String[2][4];
		
		data[0][0]="Wipro";
		data[0][1]="Rohan";
		data[0][2]="Krishna";
		data[0][3]="98";
		
		data[1][0]="Comstar";
		data[1][1]="Seenuvas";
		data[1][2]="Rohan";
		data[1][3]="97";
		
		return data;
		
	}
}






