package constructor;

public class ExampleForThis {
	
	int empId;
	String empName;
	String companyName;
	boolean empStatus;
	
	ExampleForThis()
	{
		System.out.println("Default Constructor");
	}
	
	ExampleForThis(int id,String empName,String compName,boolean status)
	{
		this();
		this.empId=id;
		this.empName=empName;
		this.companyName=compName;
		this.empStatus=status;
	}
	
	public static void main(String[] args) {
		
		ExampleForThis emp=new ExampleForThis(18,"Rohan","Apple",true);
		
		System.out.println(emp.empId);
		System.out.println(emp.empName);
		System.out.println(emp.companyName);
		System.out.println(emp.empStatus);
		
	}
	

}
