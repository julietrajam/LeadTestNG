package testNGLearning;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LearnAssertion {
  
	    public static ChromeDriver driver;
	    @Test
        public void runCreateLead() {
		
	    	String expTitle="TestLeaf Automation Platform";
	    	WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.get("http://leaftaps.com/opentaps");
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			driver.findElement(By.id("username")).sendKeys("demosalesmanager");
			driver.findElement(By.id("password")).sendKeys("crmsfa");
			driver.findElement(By.className("decorativeSubmit")).click();
			String actTitle=driver.getTitle();
			
			SoftAssert softAssert=new SoftAssert();
			
			softAssert.assertEquals(actTitle, expTitle);
			softAssert.assertAll();
			
			/* To compare 2 values(int or String)
			String actTitle=driver.getTitle();
			Assert.assertEquals(actTitle, expTitle);
			*/
			
			/*
			boolean displayed=driver.findElement(By.linkText("CRM/SFA")).isDisplayed();
			Assert.assertTrue(displayed);//When the value is True - Pass When the value is False-Fail
	        
			//Assert.assertFalse(displayed);//When the value is False-Pass
	        */
	    }	
	
}
