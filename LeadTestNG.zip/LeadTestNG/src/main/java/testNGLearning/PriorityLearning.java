package testNGLearning;

import org.testng.annotations.Test;

public class PriorityLearning {
	
	@Test(priority=-1,invocationCount=5)
	public void createLead()
	{
		System.out.println("Create Lead");
	}
	
	@Test(enabled = false)
	public void editLead()
	{
		System.out.println("Edit Lead");
	}
	
	@Test
	public void deleteteLead()
	{
		System.out.println("Delete Lead");
	}
	
	@Test
	public void mergeLead()
	{
		System.out.println("Merge Lead");
	}
	
	@Test
	public void duplicateLead()
	{
		System.out.println("Duplicate Lead");
	}

}
