package constructor;

public class Employee extends CompanyInfo{
	
	String employeeName;
	int empId;
	String companyName;
	boolean employeeStatus;
	
	Employee()
	{
		System.out.println("Child Constructor-Employee");
	}
	
	public static void main(String[] args) {
		
		Employee emp=new Employee();
		
		
		/*
		System.out.println("Employee Name: "+emp.employeeName);
		System.out.println("Employee Id: "+emp.empId);
		System.out.println("Company Name :"+emp.companyName);
		System.out.println("Employee Status :"+emp.employeeStatus);
		*/
	}

}
