package testNGLearning;

import org.testng.annotations.Test;

public class LearnGrouping {

	@Test(groups="functional")
	public void createLead()
	{
		System.out.println("Create Lead");
	}
	
	@Test(groups= {"functional","smoke"})
	public void editLead()
	{
		System.out.println("Edit Lead");
	}
	
	@Test(groups="regression")
	public void deleteLead()
	{
		System.out.println("Delete Lead");
	}
	
	@Test(groups= {"functional","regression"})
	public void duplicateLead()
	{
		System.out.println("Duplicate Lead");
	}
	
	@Test(groups= {"smoke"})
	public void mergeeLead()
	{
		System.out.println("Merge Lead");
	}
	
	
}
