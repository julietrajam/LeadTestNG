package constructor;

public class DefConstructor {

	String employeeName;
	int empId;
	String companyName;
	boolean employeeStatus;
	
	public static void main(String[] args) {
		
		DefConstructor emp=new DefConstructor();
		System.out.println("Employee Name: "+emp.employeeName);
		System.out.println("Employee Id: "+emp.empId);
		System.out.println("Company Name :"+emp.companyName);
		System.out.println("Employee Status :"+emp.employeeStatus);
		
	}
	
}
