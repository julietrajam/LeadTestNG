package constructor;

public class CompanyInfo {
	
	public CompanyInfo() {
		// TODO Auto-generated constructor stub
		System.out.println("Parent Constructor-CompanyInfo");	
	}

}
