package testNGLearning;

import org.testng.annotations.Test;

public class LearnDependencybwTestcases {
	
	@Test
	public void createLead()
	{
		System.out.println("Create Lead");
	}
	
	@Test(dependsOnMethods = "createLead")
	public void editLead()
	{
		System.out.println("Edit Lead");
	}
	
	@Test
	public void deleteLead() {
		System.out.println("Delete Lead");
	}

}
